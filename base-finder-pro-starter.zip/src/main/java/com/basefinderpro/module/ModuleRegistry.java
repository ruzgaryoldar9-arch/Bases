package com.basefinderpro.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleRegistry {
    private static final List<Module> MODULES = new ArrayList<>();
    private static boolean registered;

    private ModuleRegistry() {}

    public static void registerDefaults() {
        if (registered) return;
        registered = true;
        add("Chunk Coordinates", "Shows the current chunk coordinates.", ModuleCategory.CHUNK);
        add("Chunk Borders", "Draws the current chunk grid where supported.", ModuleCategory.CHUNK);
        add("Chunk Notes", "Keeps local notes for inspected chunks (planned persistence).", ModuleCategory.CHUNK);
        add("Chest ESP", "Highlights accessible chest block entities in loaded chunks.", ModuleCategory.STORAGE_ESP);
        add("Barrel ESP", "Highlights accessible barrels in loaded chunks.", ModuleCategory.STORAGE_ESP);
        add("Container Labels", "Displays container type labels in the overlay.", ModuleCategory.STORAGE_ESP);
        add("Base Candidate Detector", "Scores nearby loaded blocks for man-made structure patterns.", ModuleCategory.BASE_FINDER);
        add("Tunnel Detector", "Analyzes exposed, loaded blocks for tunnel-like geometry.", ModuleCategory.BASE_FINDER);
        add("Entrance Detector", "Marks candidate entrances found in scanned loaded blocks.", ModuleCategory.BASE_FINDER);
        add("Obsidian Finder", "Finds selected obsidian blocks in loaded chunks.", ModuleCategory.BLOCK_FINDER);
        add("Ladder Finder", "Finds ladders in loaded chunks.", ModuleCategory.BLOCK_FINDER);
        add("Redstone Component Finder", "Finds selected redstone components in loaded chunks.", ModuleCategory.BLOCK_FINDER);
        add("Cave Entrance Markers", "Marks cave openings visible in loaded terrain.", ModuleCategory.CAVE_EXPLORER);
        add("Height Map", "Shows local height information.", ModuleCategory.CAVE_EXPLORER);
        add("Coordinates HUD", "Displays player coordinates.", ModuleCategory.NAVIGATION);
        add("Waypoints", "Stores local navigation markers (configuration integration pending).", ModuleCategory.NAVIGATION);
        add("Storage Cluster Analysis", "Groups nearby visible storage blocks.", ModuleCategory.ANALYSIS);
        add("Block Density", "Counts selected blocks within a bounded scan budget.", ModuleCategory.ANALYSIS);
        add("HUD Editor", "Opens the HUD settings panel.", ModuleCategory.INTERFACE);
        add("Incremental Scanning", "Limits work per tick to reduce frame-time spikes.", ModuleCategory.PERFORMANCE);
        add("Duplicate Result Filter", "Deduplicates scan results by block position.", ModuleCategory.PERFORMANCE);
        add("Search Report", "Exports scan summaries (JSON writer integration pending).", ModuleCategory.DATA);
    }

    private static void add(String name, String description, ModuleCategory category) {
        MODULES.add(new Module(name, description, category));
    }

    public static List<Module> all() {
        return Collections.unmodifiableList(MODULES);
    }
}
