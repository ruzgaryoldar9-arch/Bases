package com.basefinderpro.module;

public enum ModuleCategory {
    CHUNK, STORAGE_ESP, BASE_FINDER, BLOCK_FINDER, CAVE_EXPLORER,
    NAVIGATION, ANALYSIS, INTERFACE, PERFORMANCE, DATA
}
