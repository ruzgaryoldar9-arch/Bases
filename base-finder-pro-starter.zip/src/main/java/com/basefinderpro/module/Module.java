package com.basefinderpro.module;

public final class Module {
    private final String name;
    private final String description;
    private final ModuleCategory category;
    private boolean enabled;
    private int color = 0xFF55D6BE;
    private int scanRadius = 32;

    public Module(String name, String description, ModuleCategory category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public String name() { return name; }
    public String description() { return description; }
    public ModuleCategory category() { return category; }
    public boolean enabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public int color() { return color; }
    public void setColor(int color) { this.color = color; }
    public int scanRadius() { return scanRadius; }
    public void setScanRadius(int scanRadius) {
        this.scanRadius = Math.max(4, Math.min(128, scanRadius));
    }
}
