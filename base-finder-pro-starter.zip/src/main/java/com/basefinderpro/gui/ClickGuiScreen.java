package com.basefinderpro.gui;

import com.basefinderpro.module.Module;
import com.basefinderpro.module.ModuleCategory;
import com.basefinderpro.module.ModuleRegistry;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ClickGuiScreen extends Screen {
    private ModuleCategory selectedCategory = ModuleCategory.CHUNK;
    private String search = "";
    private int scrollOffset = 0;
    private Module settingsModule;
    private boolean editingSearch = false;

    private static final int PANEL_W = 520;
    private static final int PANEL_H = 330;
    private static final int HEADER_H = 36;
    private static final int SIDEBAR_W = 126;

    public ClickGuiScreen() {
        super(Text.literal("Base Finder Pro"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int x = (width - PANEL_W) / 2;
        int y = (height - PANEL_H) / 2;

        context.fill(x, y, x + PANEL_W, y + PANEL_H, 0xF0181C27);
        context.fill(x, y, x + PANEL_W, y + HEADER_H, 0xFF252D3B);
        context.fill(x, y + HEADER_H, x + SIDEBAR_W, y + PANEL_H, 0xFF202633);
        context.drawTextWithShadow(textRenderer, Text.literal("BASE FINDER PRO"), x + 12, y + 12, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, Text.literal("Right Shift / ESC"), x + PANEL_W - 112, y + 12, 0xFFB9C4D6);

        int cy = y + HEADER_H + 12;
        for (ModuleCategory category : ModuleCategory.values()) {
            boolean selected = category == selectedCategory;
            int rowY = cy;
            if (selected) context.fill(x + 6, rowY - 4, x + SIDEBAR_W - 6, rowY + 15, 0xFF34495E);
            context.drawTextWithShadow(textRenderer, Text.literal(pretty(category)), x + 14, rowY, selected ? 0xFF65E6C4 : 0xFFD3D9E4);
            cy += 25;
        }

        int contentX = x + SIDEBAR_W + 14;
        int contentW = PANEL_W - SIDEBAR_W - 28;
        context.fill(contentX, y + HEADER_H + 9, contentX + contentW, y + HEADER_H + 31, 0xFF10151D);
        String searchLabel = search.isEmpty() ? "Search modules..." : search + (editingSearch ? "|" : "");
        context.drawTextWithShadow(textRenderer, Text.literal(searchLabel), contentX + 8, y + HEADER_H + 16, 0xFFB9C4D6);

        if (settingsModule != null) {
            renderSettings(context, contentX, y + HEADER_H + 44, contentW);
        } else {
            List<Module> visible = visibleModules();
            int listY = y + HEADER_H + 42;
            int rowH = 28;
            int maxRows = (PANEL_H - HEADER_H - 50) / rowH;
            for (int i = scrollOffset; i < Math.min(visible.size(), scrollOffset + maxRows); i++) {
                Module module = visible.get(i);
                int ry = listY + (i - scrollOffset) * rowH;
                context.fill(contentX, ry, contentX + contentW, ry + 24, 0xFF252D3B);
                context.drawTextWithShadow(textRenderer, Text.literal(module.name()), contentX + 8, ry + 5, 0xFFF0F3F8);
                context.drawTextWithShadow(textRenderer, Text.literal(module.enabled() ? "[ ON ]" : "[ OFF ]"),
                        contentX + contentW - 54, ry + 5, module.enabled() ? 0xFF65E6C4 : 0xFF9AA6B7);
                context.drawTextWithShadow(textRenderer, Text.literal("⚙"),
                        contentX + contentW - 78, ry + 5, 0xFFD3D9E4);
            }
            context.drawTextWithShadow(textRenderer,
                    Text.literal(visible.size() + " modules · click row to toggle · click ⚙ for settings"),
                    contentX, y + PANEL_H - 18, 0xFF9AA6B7);
        }
        super.render(context, mouseX, mouseY, delta);
    }

    private void renderSettings(DrawContext context, int x, int y, int w) {
        context.drawTextWithShadow(textRenderer, Text.literal(settingsModule.name()), x, y, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, Text.literal(settingsModule.description()), x, y + 22, 0xFFB9C4D6);
        context.drawTextWithShadow(textRenderer, Text.literal("ESP color: click below to cycle presets"), x, y + 58, 0xFFD3D9E4);
        context.fill(x, y + 78, x + 110, y + 102, settingsModule.color());
        context.drawTextWithShadow(textRenderer, Text.literal(String.format("#%06X", settingsModule.color() & 0xFFFFFF)),
                x + 120, y + 86, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, Text.literal("Scan radius: " + settingsModule.scanRadius() + " blocks"), x, y + 124, 0xFFD3D9E4);
        context.drawTextWithShadow(textRenderer, Text.literal("Click this line to cycle radius"), x, y + 143, 0xFF9AA6B7);
        context.drawTextWithShadow(textRenderer, Text.literal("← Back"), x, y + 185, 0xFF65E6C4);
    }

    private List<Module> visibleModules() {
        List<Module> result = new ArrayList<>();
        String needle = search.toLowerCase(Locale.ROOT);
        for (Module m : ModuleRegistry.all()) {
            if (m.category() == selectedCategory && m.name().toLowerCase(Locale.ROOT).contains(needle)) {
                result.add(m);
            }
        }
        return result;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int x = (width - PANEL_W) / 2;
        int y = (height - PANEL_H) / 2;
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);

        if (mouseY >= y + HEADER_H + 8 && mouseY < y + PANEL_H && mouseX >= x && mouseX < x + SIDEBAR_W) {
            int index = (int) ((mouseY - (y + HEADER_H + 8)) / 25);
            if (index >= 0 && index < ModuleCategory.values().length) {
                selectedCategory = ModuleCategory.values()[index];
                scrollOffset = 0;
                settingsModule = null;
                return true;
            }
        }

        int contentX = x + SIDEBAR_W + 14;
        int contentW = PANEL_W - SIDEBAR_W - 28;
        if (mouseX >= contentX && mouseX <= contentX + contentW &&
                mouseY >= y + HEADER_H + 9 && mouseY <= y + HEADER_H + 31) {
            editingSearch = true;
            return true;
        }

        if (settingsModule != null) {
            int sy = y + HEADER_H + 44;
            if (mouseY >= sy + 75 && mouseY <= sy + 106) {
                int[] colors = {0xFF55D6BE, 0xFFFFB454, 0xFFFF6685, 0xFF8B7CFF, 0xFFFFFFFF};
                int next = 0;
                for (int i = 0; i < colors.length; i++) if (colors[i] == settingsModule.color()) next = (i + 1) % colors.length;
                settingsModule.setColor(colors[next]);
                return true;
            }
            if (mouseY >= sy + 118 && mouseY <= sy + 160) {
                settingsModule.setScanRadius(settingsModule.scanRadius() >= 128 ? 16 : settingsModule.scanRadius() + 16);
                return true;
            }
            if (mouseY >= sy + 178 && mouseY <= sy + 205) {
                settingsModule = null;
                return true;
            }
            return true;
        }

        int listY = y + HEADER_H + 42;
        int rowH = 28;
        int row = (int) ((mouseY - listY) / rowH) + scrollOffset;
        List<Module> visible = visibleModules();
        if (mouseY >= listY && row >= 0 && row < visible.size()) {
            Module module = visible.get(row);
            if (mouseX >= contentX + contentW - 90) {
                settingsModule = module;
            } else {
                module.setEnabled(!module.enabled());
            }
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (editingSearch && !Character.isISOControl(chr)) {
            search += chr;
            scrollOffset = 0;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            if (settingsModule != null) settingsModule = null;
            else close();
            return true;
        }
        if (editingSearch && keyCode == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) {
            search = search.substring(0, search.length() - 1);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ENTER) editingSearch = false;
        if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !editingSearch && settingsModule != null) {
            settingsModule = null;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (settingsModule == null) {
            int size = visibleModules().size();
            scrollOffset = Math.max(0, Math.min(Math.max(0, size - 1), scrollOffset + (verticalAmount < 0 ? 1 : -1)));
        }
        return true;
    }

    private static String pretty(ModuleCategory category) {
        String s = category.name().replace('_', ' ').toLowerCase(Locale.ROOT);
        String[] words = s.split(" ");
        StringBuilder out = new StringBuilder();
        for (String word : words) {
            if (!out.isEmpty()) out.append(' ');
            out.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return out.toString();
    }
}
