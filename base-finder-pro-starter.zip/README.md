# Base Finder Pro (Fabric client mod)

## Scope of this starter
This project is a GUI/module-registry foundation. It includes Right Shift keybinding, ESC closing, categories, module search, toggles, per-module color presets and scan-radius settings. Most registered modules are UI/module definitions only; the actual world scanners, persistence, ESP rendering, reports, and the 100+ module suite are not implemented yet.

The mod is client-only and must only analyze world data available to the client. It does not reveal unloaded remote chunks or bypass server permissions.

## Toolchain
Minecraft 1.21.11 requires Java 21 or newer. Use a JDK 21 installation. Fabric Loom/Yarn/Fabric API versions are configured in `gradle.properties`; if Fabric's Maven does not contain one of the selected coordinates, replace it with the version listed for Minecraft 1.21.11 on Fabric's official Develop page.

## Build
1. Install JDK 21.
2. Open this folder in IntelliJ IDEA or another Gradle-capable IDE.
3. Allow Gradle to sync dependencies.
4. Run `gradle build` (or `./gradlew build` if you add the Gradle wrapper).
5. The remapped jar should be in `build/libs/`.
6. Put the jar and a matching Fabric API jar in `.minecraft/mods`, then launch the Fabric 1.21.11 profile.

This archive intentionally does not include generated Gradle wrapper binaries. On a computer with Gradle installed, run `gradle wrapper --gradle-version 8.14.3`, then use `./gradlew build`.

## GUI
- Right Shift toggles the screen through Fabric's keybinding API.
- ESC closes the GUI (or returns from module settings).
- Click a category on the left, click the search field and type, click a module row to toggle it, and click the right-hand settings area for color/radius options.
- GUI does not pause single-player simulation (`shouldPause() == false`).

## Verification status
Source scaffold generated, but not compiled in this environment. Confirm dependency coordinates and resolve any mapping/API differences with `gradle build` before treating the jar as release-ready.
